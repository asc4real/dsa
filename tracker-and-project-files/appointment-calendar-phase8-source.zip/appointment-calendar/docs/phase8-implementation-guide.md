# Phase 8 — Actual implementation guide and status

**Date:** 2026-10-19. **Status:** source draft; incomplete and unverified as a Spring Boot application. This is the first vertical implementation batch of a larger Phase 8 project. It is not a replacement for the Phase 7 blueprint.

## 1. Architecture in this batch

- **Single executable Spring Boot module:** `com.acme.appointmentcalendar` with feature packages.
- **Security boundary:** OAuth2 Resource Server validates configured issuer, JWT signature/lifetime and audience; `TenantAccessPolicy` resolves an `(issuer,subject)` user profile and active membership from PostgreSQL.
- **Catalog:** `CatalogReader` loads active services and tenant-qualified location/resource eligibility.
- **Availability:** `AvailabilityEngine` resolves resource combinations, weekly time windows, blocked intervals, buffers, notice, horizon, DST offsets, and the current reservation state. Current algorithm is intentionally bounded but not optimized.
- **Reservations:** `ReservationStore` writes authoritative rows; PostgreSQL GiST exclusion constraint rejects resource overlaps (SQLSTATE `23P01`).
- **Booking:** `BookingApplicationService` orchestrates short Spring `@Transactional` workflows. Hold confirmation changes reservation ownership without releasing and reacquiring resources.
- **Idempotency:** `IdempotencyCoordinator` uses unique `ON CONFLICT DO NOTHING` key insertion and resource result persistence in the booking transaction.
- **Auditing/outbox:** `AuditWriter` and `OutboxWriter` write durable records in the same transaction. **Dispatch remains unimplemented.**
- **Expiry:** `HoldExpiryWorker` uses `FOR UPDATE SKIP LOCKED` with batches of 100 every 15 seconds.

## 2. Why PostgreSQL is authoritative

Active reservations have a composite GiST exclusion constraint:

```sql
CREATE EXTENSION IF NOT EXISTS btree_gist;
ALTER TABLE resource_reservation ADD CONSTRAINT active_resource_no_overlap
EXCLUDE USING GIST (
  organization_id WITH =,
  resource_id WITH =,
  tstzrange(occupied_start,occupied_end,'[)') WITH &&
) WHERE (state='ACTIVE');
```

This preserves a half-open interval invariant for all pods. Java prechecks merely improve UX and cannot guarantee successful booking.

### Multi-resource transaction

```text
BEGIN
  validate actor and tenant
  validate service/location/resource eligibility
  allocate all required resources
  create booking hold or appointment
  insert reservations in deterministic UUID order
  write audit + outbox + idempotency result
COMMIT
```

If the final resource conflicts, the transaction rolls back every earlier reservation write.

## 3. Booking hold creation details

- `Idempotency-Key` must be a bounded string.
- The owner is derived from the current application identity, never the body.
- Lock the customer's membership row before counting active holds; max-three active holds is safe for simultaneous requests by one principal.
- Snapshot duration/buffers/deadlines onto the hold at creation.
- Capture expiration with PostgreSQL transaction time.
- Insert ACTIVE reservations for all selected resources.
- Return 201 with hold details or map PostgreSQL exclusion to a stable 409.

### Remaining quota/abuse requirements

Rate limits for per-IP/per-tenant requests, anti-bot measures and monitoring are not implemented. Authentication alone does not prevent distributed slot-hoarding attacks using distinct accounts.

## 4. Hold confirmation and expiration race

1. Lock hold `FOR UPDATE`.
2. Require ACTIVE status and `expires_at > transaction_timestamp()`.
3. Insert appointment using the hold's immutable timing/policy snapshot.
4. Convert reservations from hold to appointment ownership without a release gap.
5. Mark hold CONFIRMED and append audit/outbox.
6. Commit atomically.

Expiry worker claims expired holds using SKIP LOCKED. A transaction holding the row serializes confirmation against expiration. A late cleanup does not extend the hold's logical validity; it may temporarily delay fresh booking until cleanup releases the blocking reservations.

## 5. Direct booking

Schedulers and organization admins can create an appointment on behalf of a valid active organization member. It uses the same availability, allocation and authoritative reservation constraint as customer holds. Direct booking never bypasses the database.

## 6. Cancellation

- Lock appointment row, verify authorization and current ETag.
- Check allowed status and snapshotted cancellation deadline (organization scheduler/admin may override per this initial policy).
- Change appointment status, increment version, release reservations.
- Append audit/outbox and idempotency result.
- Commit; a failed transaction leaves the original appointment unchanged.

## 7. Rescheduling

- Lock appointment, check current ETag and CONFIRMED state.
- Enforce snapshotted reschedule deadline for ordinary customers.
- Reuse original appointment duration and buffers, not any altered current service timing.
- Verify new location and active resource eligibility.
- Exclude the appointment's own existing occupied interval during candidate search.
- Mark old reservations RELEASED, insert new ACTIVE reservations and update appointment in the same transaction.
- A new-resource exclusion violation rolls back the entire operation, preserving the old booking.

**Remaining policy concern:** admin overrides, historical eligibility and existing bookings after service deactivation require policy review; provider reassignment and notification diff semantics are not complete.

## 8. Security controls implemented

- JWT signature validation via Nimbus JWT decoder and JWKS URI.
- Issuer validation, audience validation and standard expiry/time validators.
- Active organization membership derived from `(issuer,subject)`, not client-supplied `customerId`.
- Object-level ownership for hold and appointment reads and mutations.
- Scheduler/admin roles for delegated direct booking.
- Tenant-aware foreign keys and explicit tenant-scoped SQL predicates.
- Narrow mutation DTOs.
- Security-sensitive DB errors converted to safe problem responses (except any path not yet covered by a handler).

**Still missing:** comprehensive role permissions; fine-grained staff/location authorization; full JWT negative tests; many admin APIs; robust request rate limiting; formal RLS verification; token/membership revocation tests; strict JSON/DTO introspection tests; fully consistent RFC 9457 responses for framework-generated errors; threat-register closure.

## 9. Persistence schema

| File | Contents |
|---|---|
| `V001__identity_organization_resources.sql` | organization, profile, membership, location, staff, resource, service, requirements, availability rules and unavailability |
| `V002__holds_appointments_reservations.sql` | booking hold, appointment, owner FK, reservation/exclusion constraint, booking indexes |
| `V003__idempotency_audit_outbox.sql` | idempotency, audit and durable outbox |
| `db/local/V1000__local_sample_data.sql` | local-only Keycloak users, organization, service, staff, room, eligibility and weekday rules |

Note that these three broad initial migrations intentionally differ from the 12-file Phase 7 migration decomposition. They are source drafts for the first slice. **Before release**, converge to a reviewed migration history; do not rewrite migrations that have already been applied in an environment.

## 10. Test plan / current evidence

Tests included:

- `ReservationIntervalTest`: touching intervals and a 1ms overlap.
- `DaylightSavingRulesTest`: New York spring gap/fall overlap.
- `NoDoubleBooking100ThreadsIT`: 100 distinct holds, one tenant/resource/time, actual PostgreSQL exclusion insert, expected exactly one success.

`maven-failsafe-plugin` is configured for `*IT` integration tests. Its behavior must be confirmed under the actual Java 25/Maven environment.

The authoring environment has only **Java 21** and no Maven or Docker daemon/internet package access. Accordingly:

- XML parsing: checked.
- Existing OpenAPI YAML parsing: checked.
- Dependency-free Java record compilation using `javac` 21: checked.
- Full Spring Boot source compilation: **NOT CHECKED**.
- Flyway SQL execution on PostgreSQL: **NOT CHECKED**.
- Testcontainers concurrency and JUnit tests: **NOT RUN**.
- Local Keycloak token issuance: **NOT CHECKED**.
- Startup, REST behavior, performance/security tests: **NOT CHECKED**.

This is NOT a passing production build. The next environment with Java 25, Docker and package access must run `./mvnw clean verify` and correct every failure before promoting status.

## 11. Remaining Phase 8 implementation slices

### Slice B — Complete CRUD and administrative APIs
- `/me` and `/me/memberships`, organization creation/configuration, roles, membership management and last-admin protection.
- Service, location, resource and staff management endpoints.
- Recurring availability, exception and time-off CRUD with version checks and audit.
- Company/staff policy fields, organization/location business hours, correct overnight windows.

### Slice C — Appointment lifecycle, queries and API fidelity
- All 67 OpenAPI operations; resource status history, check-in, start, complete, no-show.
- Customer and staff pagination, secure keyset cursors, service filtering.
- Comprehensive DTO-to-OpenAPI contract tests; ETag/If-Match consistency; safe errors for every path.

### Slice D — Resilience and communication
- Durable outbox dispatcher with bounded claims and leases, idempotent notification handler, retries/dead-letter states, Mailpit integration.
- Persistent reminder generation and multi-instance-safe workers.
- External provider ports, webhook SSRF/replay protection only if enabled.

### Slice E — Security, tenant/data integrity and performance
- Full ASVS control matrix, negative JWT/tenant/BOLA tests, authorization across all routes.
- Postgres RLS proof or documented alternative, separate DB migration/runtime roles.
- Optimized batch availability engine and k6 workload tests.
- Rate limits, fair slot hoarding protections, privacy retention/export/deletion workflows.

### Slice F — Production/infrastructure
- CI/CD, container scanning, SBOM, image provenance, Kubernetes YAML, secret manager, metrics/tracing.
- Backup/recovery tests, load test evidence, ADRs, operational runbook, external security reviews.
- Fix all blocker/high findings before readiness sign-off.

## 12. Source-of-truth and contract drift policy

The original 67-operation `openapi/appointment-calendar.yaml` is included as a design target; it must NOT be presented as already backed by controllers. The slice covers only 9 operations. Changes to URI, DTO or response semantics must update OpenAPI and be contract-tested once the full test harness is available.

The original Phase 7 432-entry manifest is kept in `docs/phase7-original-repository-manifest.md`. A derived progress manifest tracks draft files without falsely marking them VERIFIED.
