# Appointment Calendar — Phase 8 implementation slice

**Status: IMPLEMENTATION IN PROGRESS — NOT PRODUCTION READY.**

This archive is a real **source repository draft** accompanying Phase 8, not a complete implementation of the original 432-file Phase 7 plan. It uses Spring Boot 4.1.1, Java 25, Spring Security OAuth2 Resource Server, PostgreSQL 18, Flyway, and JDBC for authoritative reservations. The complete Phase 5 OpenAPI contract is included for reference, but only the 9 operations listed below are implemented in this slice.

## Implemented endpoints (9/67)

| Method | Path (prefix `/api/v1/organizations/{orgId}`) |
| --- | --- |
| POST | `/availability/search` |
| POST | `/booking-holds` |
| GET | `/booking-holds/{holdId}` |
| POST | `/booking-holds/{holdId}/confirm` |
| POST | `/booking-holds/{holdId}/cancel` |
| POST | `/appointments` (scheduler/admin) |
| GET | `/appointments/{appointmentId}` |
| POST | `/appointments/{appointmentId}/cancel` |
| POST | `/appointments/{appointmentId}/reschedule` |

A PostgreSQL `btree_gist` exclusion constraint prevents two overlapping ACTIVE reservations for the same tenant/resource. Temporary holds and appointments share the same reservation table. Spring-managed database transactions protect holds, confirmations, reschedules and cancellations. An idempotency-key table participates in the same transaction.

## Requirements

- Java **25** JDK (required by `pom.xml`)
- Docker and Docker Compose (PostgreSQL 18, Keycloak local, Mailpit)
- Internet access to retrieve official Maven artifacts on first build, unless dependencies are already cached
- `curl`/`unzip`/`sha512sum` on Linux/macOS, or PowerShell on Windows for the bundled **lightweight checksum-verified Maven bootstrap**. These scripts are *not* the official generated Apache Maven Wrapper; `mvn -N wrapper:wrapper` can replace them later.

## Start local dependencies

```bash
docker compose up -d db keycloak mailpit
```

The Compose environment uses **public, local-development-only credentials**. Never reuse these in production.

## Verify / run

```bash
java -version                   # must show JDK 25
./mvnw clean verify             # runs unit tests and PostgreSQL Testcontainers integration tests
SPRING_PROFILES_ACTIVE=local DATABASE_PASSWORD=local-only ./mvnw spring-boot:run
```

Windows PowerShell:

```powershell
.\mvnw.cmd clean verify
$env:SPRING_PROFILES_ACTIVE = 'local'
$env:DATABASE_PASSWORD = 'local-only'
.\mvnw.cmd spring-boot:run
```

> WARNING: The repository has **not** been compiled or run against Spring Boot 4.1/Java 25 in the authoring environment. Only dependency-free Java classes and structural checks could be executed there. A green `./mvnw clean verify` in your environment is the required first real validation gate.

## Local sample data

`application-local.yml` loads `db/local/V1000__local_sample_data.sql`. **Never** enable this path in production.

- Tenant: `11111111-1111-4111-8111-111111111111`
- Location: `22222222-2222-4222-8222-222222222222`
- Staff: `33333333-3333-4333-8333-333333333333`
- Service: `66666666-6666-4666-8666-666666666666`
- Room resource: `55555555-5555-4555-8555-555555555555`
- Staff resource: `44444444-4444-4444-8444-444444444444`
- Alice user: `alice`, password: `local-only-password`
- Sam scheduler: `sam`, password: `local-only-password`
- OIDC CLI client: `appointment-calendar-cli` (direct grant enabled **only** for localhost testing)

## Get a local development token

```bash
TOKEN=$(curl -fsS \
  -X POST 'http://localhost:8082/realms/appointments-local/protocol/openid-connect/token' \
  -d 'client_id=appointment-calendar-cli' \
  -d 'grant_type=password' \
  -d 'username=alice' \
  -d 'password=local-only-password' \
  | python3 -c 'import json,sys; print(json.load(sys.stdin)["access_token"])')
```

Resource Owner Password Credentials is used **only** as a convenience in the sandbox Keycloak realm for local command-line tests. Production browser clients must use Authorization Code + PKCE/BFF strategies; do not enable password grants for production clients.

## Search (select a future weekday)

```bash
ORG=11111111-1111-4111-8111-111111111111
curl -i -X POST "http://localhost:8080/api/v1/organizations/$ORG/availability/search" \
 -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
 -d '{"serviceId":"66666666-6666-4666-8666-666666666666", "locationId":"22222222-2222-4222-8222-222222222222", "dateFrom":"2026-10-20", "dateToExclusive":"2026-10-21", "displayTimeZone":"Asia/Kolkata"}'
```

Dates above demonstrate the API shape as of October 2026. If they are past dates when you run this, replace them with a future Monday–Friday within the configured booking horizon.

## Create a five-minute hold

```bash
curl -i -X POST "http://localhost:8080/api/v1/organizations/$ORG/booking-holds" \
 -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
 -H "Idempotency-Key: $(python3 -c 'import uuid; print(uuid.uuid4())')" \
 -d '{"serviceId":"66666666-6666-4666-8666-666666666666", "locationId":"22222222-2222-4222-8222-222222222222", "startAt":"2026-10-20T04:30:00Z"}'
```

Extract `id` from the response, then confirm with a **new** idempotency key:

```bash
curl -i -X POST "http://localhost:8080/api/v1/organizations/$ORG/booking-holds/$HOLD_ID/confirm" \
 -H "Authorization: Bearer $TOKEN" -H "Idempotency-Key: $(python3 -c 'import uuid; print(uuid.uuid4())')"
```

## Major limitations / blockers

- Only 9/67 APIs exist; administration, scheduling CRUD, listing, lifecycle commands, reminder configuration, audit retrieval and others remain outstanding.
- No notification/outbox dispatcher or email delivery implementation yet. The outbox records are durable but never consumed by this slice.
- No complete customer/staff/privacy authorization and denial-test suite yet.
- Availability search currently performs repeated queries per slot/resource; **performance is not production adequate** for large searches.
- Business hours, special opening days and some exception types are not implemented (only resource weekly rules and blocked intervals are represented).
- DST time gaps/overlaps are handled conservatively, but edge crossing and local-day overnight service policies are not supported.
- Booking status transitions beyond cancellation/rescheduling, audit history, keyset pagination, comprehensive reminders, RLS and CI/CD remain for subsequent batches.
- One-row-per-active-hold quota is serialized at membership level; cross-tenant bot defenses and WAF rate limits are not implemented.
- Idempotency records track logical resource IDs, not immutable response snapshots; the representation on a later replay may reflect updated state.
- Database runtime and migration users are not yet separated in local Compose.
- No real Maven/Docker/PostgreSQL test run has been performed in the authoring environment.

See [implementation guide](docs/phase8-implementation-guide.md) and [status report](docs/phase8-verification-report.json) for the complete technical account.
