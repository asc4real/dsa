-- Strictly local development seed: NEVER include db/local in production Flyway locations.
INSERT INTO organization(id,name,zone_id) VALUES
 ('11111111-1111-4111-8111-111111111111','Acme Appointments','Asia/Kolkata');
INSERT INTO user_profile(id,issuer,subject,display_name) VALUES
 ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','http://localhost:8082/realms/appointments-local','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','Alice Customer'),
 ('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','http://localhost:8082/realms/appointments-local','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','Sam Scheduler');
INSERT INTO organization_membership(organization_id,user_profile_id,role) VALUES
 ('11111111-1111-4111-8111-111111111111','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','CUSTOMER'),
 ('11111111-1111-4111-8111-111111111111','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','SCHEDULER');
INSERT INTO location(id,organization_id,name,zone_id) VALUES
 ('22222222-2222-4222-8222-222222222222','11111111-1111-4111-8111-111111111111','Main Office','Asia/Kolkata');
INSERT INTO staff_member(id,organization_id,name) VALUES
 ('33333333-3333-4333-8333-333333333333','11111111-1111-4111-8111-111111111111','Provider Alice');
INSERT INTO calendar_resource(id,organization_id,location_id,staff_member_id,type,name) VALUES
 ('44444444-4444-4444-8444-444444444444','11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222','33333333-3333-4333-8333-333333333333','STAFF_MEMBER','Alice provider resource'),
 ('55555555-5555-4555-8555-555555555555','11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222',NULL,'ROOM','Room 1');
INSERT INTO bookable_service(id,organization_id,name,duration_minutes,buffer_before_minutes,buffer_after_minutes,notice_minutes,horizon_days) VALUES
 ('66666666-6666-4666-8666-666666666666','11111111-1111-4111-8111-111111111111','Consultation',30,10,10,30,90);
INSERT INTO service_location(organization_id,service_id,location_id) VALUES
 ('11111111-1111-4111-8111-111111111111','66666666-6666-4666-8666-666666666666','22222222-2222-4222-8222-222222222222');
INSERT INTO service_resource_requirement(id,organization_id,service_id,requirement_key,resource_type) VALUES
 ('77777777-7777-4777-8777-777777777777','11111111-1111-4111-8111-111111111111','66666666-6666-4666-8666-666666666666','provider','STAFF_MEMBER'),
 ('88888888-8888-4888-8888-888888888888','11111111-1111-4111-8111-111111111111','66666666-6666-4666-8666-666666666666','room','ROOM');
INSERT INTO service_resource_eligibility(organization_id,requirement_id,resource_id) VALUES
 ('11111111-1111-4111-8111-111111111111','77777777-7777-4777-8777-777777777777','44444444-4444-4444-8444-444444444444'),
 ('11111111-1111-4111-8111-111111111111','88888888-8888-4888-8888-888888888888','55555555-5555-4555-8555-555555555555');
INSERT INTO availability_rule(id,organization_id,resource_id,iso_weekday,local_start,local_end)
SELECT gen_random_uuid(),'11111111-1111-4111-8111-111111111111',r.id,d,'09:00'::time,'17:00'::time
FROM calendar_resource r CROSS JOIN generate_series(1,5) d
WHERE r.organization_id='11111111-1111-4111-8111-111111111111';
