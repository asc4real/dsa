CREATE TABLE booking_hold (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL REFERENCES organization(id),
 customer_id UUID NOT NULL, service_id UUID NOT NULL, location_id UUID NOT NULL,
 start_at TIMESTAMPTZ NOT NULL, end_at TIMESTAMPTZ NOT NULL,
 zone_id VARCHAR(64) NOT NULL, status VARCHAR(16) NOT NULL,
 service_name_snapshot VARCHAR(160) NOT NULL, duration_minutes_snapshot INT NOT NULL,
 buffer_before_minutes_snapshot INT NOT NULL, buffer_after_minutes_snapshot INT NOT NULL,
 cancel_deadline_minutes_snapshot INTEGER NOT NULL, reschedule_deadline_minutes_snapshot INTEGER NOT NULL,
 expires_at TIMESTAMPTZ NOT NULL, appointment_id UUID,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 CHECK(end_at > start_at),
 CHECK(status IN ('ACTIVE','CONFIRMED','EXPIRED','CANCELLED')),
 FOREIGN KEY (organization_id,customer_id) REFERENCES organization_membership(organization_id,user_profile_id),
 FOREIGN KEY (organization_id,service_id) REFERENCES bookable_service(organization_id,id),
 FOREIGN KEY (organization_id,location_id) REFERENCES location(organization_id,id),
 UNIQUE(organization_id,id)
);
CREATE INDEX idx_hold_expiration ON booking_hold(expires_at,id) WHERE status='ACTIVE';
CREATE INDEX idx_hold_owner ON booking_hold(organization_id,customer_id,status);
CREATE TABLE appointment (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL REFERENCES organization(id),
 customer_id UUID NOT NULL, service_id UUID NOT NULL, location_id UUID NOT NULL,
 start_at TIMESTAMPTZ NOT NULL, end_at TIMESTAMPTZ NOT NULL,
 zone_id VARCHAR(64) NOT NULL, status VARCHAR(16) NOT NULL,
 service_name_snapshot VARCHAR(160) NOT NULL, duration_minutes_snapshot INT NOT NULL,
 buffer_before_minutes_snapshot INT NOT NULL, buffer_after_minutes_snapshot INT NOT NULL,
 cancel_deadline_minutes_snapshot INTEGER NOT NULL, reschedule_deadline_minutes_snapshot INTEGER NOT NULL,
 version BIGINT NOT NULL DEFAULT 1,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 CHECK(end_at > start_at),
 CHECK(status IN ('CONFIRMED','CHECKED_IN','IN_PROGRESS','COMPLETED','CANCELLED','NO_SHOW')),
 FOREIGN KEY (organization_id,customer_id) REFERENCES organization_membership(organization_id,user_profile_id),
 FOREIGN KEY (organization_id,service_id) REFERENCES bookable_service(organization_id,id),
 FOREIGN KEY (organization_id,location_id) REFERENCES location(organization_id,id),
 UNIQUE(organization_id,id)
);
ALTER TABLE booking_hold ADD CONSTRAINT hold_appointment_fk
 FOREIGN KEY (organization_id,appointment_id) REFERENCES appointment(organization_id,id);
CREATE INDEX idx_appt_customer_date ON appointment(organization_id,customer_id,start_at,id);
CREATE TABLE resource_reservation (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL, resource_id UUID NOT NULL,
 booking_hold_id UUID, appointment_id UUID, state VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
 occupied_start TIMESTAMPTZ NOT NULL, occupied_end TIMESTAMPTZ NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 CHECK(occupied_end > occupied_start),
 CHECK(state IN ('ACTIVE','RELEASED')),
 CHECK((booking_hold_id IS NULL) <> (appointment_id IS NULL)),
 FOREIGN KEY (organization_id,resource_id) REFERENCES calendar_resource(organization_id,id),
 FOREIGN KEY (organization_id,booking_hold_id) REFERENCES booking_hold(organization_id,id),
 FOREIGN KEY (organization_id,appointment_id) REFERENCES appointment(organization_id,id)
);
ALTER TABLE resource_reservation
 ADD CONSTRAINT active_resource_no_overlap EXCLUDE USING GIST (
  organization_id WITH =,
  resource_id WITH =,
  tstzrange(occupied_start,occupied_end,'[)') WITH &&
 ) WHERE (state='ACTIVE');
CREATE INDEX idx_reservation_hold ON resource_reservation(organization_id,booking_hold_id);
CREATE INDEX idx_reservation_appointment ON resource_reservation(organization_id,appointment_id);
