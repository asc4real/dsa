CREATE EXTENSION IF NOT EXISTS btree_gist;
CREATE TABLE organization (
 id UUID PRIMARY KEY, name VARCHAR(160) NOT NULL,
 zone_id VARCHAR(64) NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
 CONSTRAINT organization_status CHECK (status IN ('ACTIVE','INACTIVE'))
);
CREATE TABLE user_profile (
 id UUID PRIMARY KEY, issuer TEXT NOT NULL, subject TEXT NOT NULL,
 display_name VARCHAR(160) NOT NULL, UNIQUE(issuer,subject)
);
CREATE TABLE organization_membership (
 organization_id UUID NOT NULL REFERENCES organization(id),
 user_profile_id UUID NOT NULL REFERENCES user_profile(id),
 role VARCHAR(24) NOT NULL, state VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
 PRIMARY KEY (organization_id, user_profile_id),
 CONSTRAINT membership_role CHECK (role IN ('CUSTOMER','STAFF','SCHEDULER','ORGANIZATION_ADMIN')),
 CONSTRAINT membership_state CHECK (state IN ('ACTIVE','REVOKED'))
);
CREATE TABLE location (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL REFERENCES organization(id),
 name VARCHAR(160) NOT NULL, zone_id VARCHAR(64) NOT NULL,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 UNIQUE(organization_id,id)
);
CREATE TABLE staff_member (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL REFERENCES organization(id),
 name VARCHAR(160) NOT NULL, user_profile_id UUID REFERENCES user_profile(id), active BOOLEAN NOT NULL DEFAULT TRUE,
 UNIQUE(organization_id,id)
);
CREATE TABLE calendar_resource (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL REFERENCES organization(id),
 location_id UUID NOT NULL, staff_member_id UUID,
 type VARCHAR(20) NOT NULL, name VARCHAR(160) NOT NULL, active BOOLEAN NOT NULL DEFAULT TRUE,
 CONSTRAINT resource_type CHECK (type IN ('STAFF_MEMBER','ROOM','CHAIR','DEVICE','VEHICLE','EQUIPMENT','OTHER')),
 FOREIGN KEY (organization_id, location_id) REFERENCES location(organization_id,id),
 FOREIGN KEY (organization_id, staff_member_id) REFERENCES staff_member(organization_id,id),
 UNIQUE(organization_id,id)
);
CREATE TABLE bookable_service (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL REFERENCES organization(id),
 name VARCHAR(160) NOT NULL, duration_minutes INTEGER NOT NULL CHECK (duration_minutes BETWEEN 1 AND 720),
 buffer_before_minutes INTEGER NOT NULL DEFAULT 0 CHECK(buffer_before_minutes BETWEEN 0 AND 120),
 buffer_after_minutes INTEGER NOT NULL DEFAULT 0 CHECK(buffer_after_minutes BETWEEN 0 AND 120),
 notice_minutes INTEGER NOT NULL DEFAULT 0 CHECK (notice_minutes >= 0),
 horizon_days INTEGER NOT NULL DEFAULT 90 CHECK (horizon_days BETWEEN 1 AND 365),
 cancel_deadline_minutes INTEGER NOT NULL DEFAULT 1440 CHECK(cancel_deadline_minutes >= 0),
 reschedule_deadline_minutes INTEGER NOT NULL DEFAULT 1440 CHECK(reschedule_deadline_minutes >= 0),
 active BOOLEAN NOT NULL DEFAULT TRUE,
 UNIQUE(organization_id,id)
);
CREATE TABLE service_location (
 organization_id UUID NOT NULL, service_id UUID NOT NULL, location_id UUID NOT NULL,
 PRIMARY KEY (organization_id,service_id,location_id),
 FOREIGN KEY (organization_id, service_id) REFERENCES bookable_service(organization_id,id),
 FOREIGN KEY (organization_id, location_id) REFERENCES location(organization_id,id)
);
CREATE TABLE service_resource_requirement (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL, service_id UUID NOT NULL,
 requirement_key VARCHAR(64) NOT NULL, resource_type VARCHAR(20) NOT NULL,
 quantity INT NOT NULL DEFAULT 1 CHECK (quantity=1),
 UNIQUE(organization_id,id), UNIQUE(organization_id,service_id,requirement_key),
 FOREIGN KEY (organization_id,service_id) REFERENCES bookable_service(organization_id,id)
);
CREATE TABLE service_resource_eligibility (
 organization_id UUID NOT NULL, requirement_id UUID NOT NULL, resource_id UUID NOT NULL,
 PRIMARY KEY(organization_id,requirement_id,resource_id),
 FOREIGN KEY (organization_id,requirement_id) REFERENCES service_resource_requirement(organization_id,id),
 FOREIGN KEY (organization_id,resource_id) REFERENCES calendar_resource(organization_id,id)
);
CREATE TABLE availability_rule (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL, resource_id UUID NOT NULL,
 iso_weekday INT NOT NULL CHECK (iso_weekday BETWEEN 1 AND 7),
 local_start TIME NOT NULL, local_end TIME NOT NULL,
 CHECK(local_end > local_start),
 FOREIGN KEY (organization_id,resource_id) REFERENCES calendar_resource(organization_id,id)
);
CREATE TABLE resource_unavailability (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL, resource_id UUID NOT NULL,
 start_at TIMESTAMPTZ NOT NULL, end_at TIMESTAMPTZ NOT NULL,
 CHECK(end_at > start_at),
 FOREIGN KEY (organization_id,resource_id) REFERENCES calendar_resource(organization_id,id)
);
CREATE INDEX idx_available_rule ON availability_rule(organization_id,resource_id,iso_weekday);
CREATE INDEX idx_resource_unavailability ON resource_unavailability(organization_id,resource_id,start_at);
