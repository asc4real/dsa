CREATE TABLE idempotency_record (
 organization_id UUID NOT NULL REFERENCES organization(id), actor_id UUID NOT NULL REFERENCES user_profile(id),
 operation VARCHAR(64) NOT NULL, idem_key VARCHAR(128) NOT NULL,
 payload_sha256 CHAR(64) NOT NULL, response_json TEXT,
 http_status INT, resource_id UUID,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 PRIMARY KEY (organization_id,actor_id,operation,idem_key)
);
CREATE INDEX idx_idempotency_age ON idempotency_record(created_at);
CREATE TABLE audit_event (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL REFERENCES organization(id),
 actor_id UUID NOT NULL REFERENCES user_profile(id),
 event_type VARCHAR(80) NOT NULL, target_id UUID NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE outbox_event (
 id UUID PRIMARY KEY, organization_id UUID NOT NULL REFERENCES organization(id),
 event_type VARCHAR(80) NOT NULL, aggregate_id UUID NOT NULL,
 payload JSONB NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'PENDING',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 available_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), attempt_count INTEGER NOT NULL DEFAULT 0,
 CHECK(status IN ('PENDING','CLAIMED','DELIVERED','FAILED'))
);
CREATE INDEX idx_outbox_claim ON outbox_event(available_at,id) WHERE status='PENDING';
