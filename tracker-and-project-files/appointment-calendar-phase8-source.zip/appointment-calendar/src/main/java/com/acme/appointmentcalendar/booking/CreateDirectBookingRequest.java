package com.acme.appointmentcalendar.booking;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.UUID;
public record CreateDirectBookingRequest(@NotNull UUID serviceId,@NotNull UUID locationId,
       @NotNull UUID customerUserProfileId,@NotNull Instant startAt, UUID preferredStaffId) {}
