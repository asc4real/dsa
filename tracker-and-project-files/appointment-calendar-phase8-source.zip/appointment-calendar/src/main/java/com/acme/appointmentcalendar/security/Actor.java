package com.acme.appointmentcalendar.security;
import java.util.UUID;
public record Actor(UUID userId, UUID organizationId, String role) {
    public boolean canManage() {return role.equals("SCHEDULER") || role.equals("ORGANIZATION_ADMIN");}
    public boolean isAdmin() {return role.equals("ORGANIZATION_ADMIN");}
}
