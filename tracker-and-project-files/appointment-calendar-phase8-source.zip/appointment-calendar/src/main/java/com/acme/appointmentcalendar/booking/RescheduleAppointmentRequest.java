package com.acme.appointmentcalendar.booking;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.Instant;
import java.util.UUID;
public record RescheduleAppointmentRequest(@NotNull Instant startAt, @NotNull UUID locationId,
     UUID preferredStaffId,@Size(max=512) String reason) {}
