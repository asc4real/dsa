package com.acme.appointmentcalendar.shared;
import java.time.Clock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class ClockConfiguration {
    @Bean Clock systemClock() { return Clock.systemUTC(); }
}
