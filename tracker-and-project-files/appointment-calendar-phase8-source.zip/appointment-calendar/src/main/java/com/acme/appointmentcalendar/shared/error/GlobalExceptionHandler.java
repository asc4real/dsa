package com.acme.appointmentcalendar.shared.error;
import java.net.URI;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.dao.DataAccessException;
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(DomainProblem.class)
    ResponseEntity<ProblemDetail> domain(DomainProblem e) {
        ProblemDetail p=ProblemDetail.forStatusAndDetail(e.status(), e.getMessage());
        p.setTitle(e.code());
        p.setType(URI.create("https://api.example.com/problems/"+e.code().toLowerCase().replace('_','-')));
        p.setProperty("errorCode",e.code());
        return ResponseEntity.status(e.status()).body(p);
    }
    @ExceptionHandler({MethodArgumentNotValidException.class,HttpMessageNotReadableException.class,MethodArgumentTypeMismatchException.class})
    ResponseEntity<ProblemDetail> badRequest(Exception ignored) {
        ProblemDetail p=ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST,"Invalid request data.");
        p.setProperty("errorCode","INVALID_REQUEST");
        return ResponseEntity.badRequest().body(p);
    }
    @ExceptionHandler(DataAccessException.class)
    ResponseEntity<ProblemDetail> unavailable(DataAccessException e) {
        // Do not expose SQL statements or constraint names.
        ProblemDetail p=ProblemDetail.forStatusAndDetail(HttpStatus.SERVICE_UNAVAILABLE,"Required persistence service is unavailable.");
        p.setProperty("errorCode","DEPENDENCY_UNAVAILABLE");
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(p);
    }
}
