package com.acme.appointmentcalendar.booking;
import java.util.UUID;
import java.time.Instant;
public record BookingHoldResponse(UUID id,UUID organizationId,UUID serviceId,UUID locationId,
    Instant startAt,Instant endAt,String timeZone,String status,Instant expiresAt,UUID appointmentId) {}
