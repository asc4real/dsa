package com.acme.appointmentcalendar.idempotency;
