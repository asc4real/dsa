package com.acme.appointmentcalendar.booking;
import com.acme.appointmentcalendar.availability.AvailabilityEngine;
import com.acme.appointmentcalendar.catalog.CatalogReader;
import com.acme.appointmentcalendar.catalog.ServiceSnapshot;
import com.acme.appointmentcalendar.security.Actor;
import com.acme.appointmentcalendar.reservation.ReservationStore;
import com.acme.appointmentcalendar.idempotency.IdempotencyCoordinator;
import com.acme.appointmentcalendar.audit.AuditWriter;
import com.acme.appointmentcalendar.outbox.OutboxWriter;
import com.acme.appointmentcalendar.shared.SqlTime;
import com.acme.appointmentcalendar.shared.error.DomainProblem;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import java.time.*;
import java.util.*;
@Service
public class BookingApplicationService {
 private final JdbcTemplate jdbc;
 private final CatalogReader catalog;
 private final AvailabilityEngine availability;
 private final ReservationStore reservation;
 private final IdempotencyCoordinator idempotency;
 private final AuditWriter audit;
 private final OutboxWriter outbox;
 private final BookingStore store;
 private final int ttl,maxHolds;
 public BookingApplicationService(JdbcTemplate jdbc,CatalogReader catalog,AvailabilityEngine availability,
         ReservationStore reservation,IdempotencyCoordinator idempotency,AuditWriter audit,
         OutboxWriter outbox,BookingStore store,
         @Value("${app.booking.hold-ttl-seconds}") int ttl,
         @Value("${app.booking.max-active-holds}") int maxHolds){
     this.jdbc=jdbc;this.catalog=catalog;this.availability=availability;
     this.reservation=reservation;this.idempotency=idempotency;this.audit=audit;
     this.outbox=outbox;this.store=store;this.ttl=ttl;this.maxHolds=maxHolds;
 }
 private void requireOwner(Actor actor,UUID owner){
     if(!actor.userId().equals(owner) && !actor.canManage()) throw DomainProblem.notFound();
 }
 @Transactional
 public BookingHoldResponse createHold(Actor actor,String key,CreateBookingHoldRequest req){
    String fingerprint=actor.organizationId()+"|"+req;
    var result=idempotency.execute(actor.organizationId(),actor.userId(),"CREATE_HOLD",key,fingerprint,()->{
        // Lock serializes active-hold quota checks across pods for this customer.
        jdbc.query("""
          SELECT user_profile_id FROM organization_membership
          WHERE organization_id=? AND user_profile_id=? AND state='ACTIVE' FOR UPDATE
          """, rs->{if(!rs.next())throw DomainProblem.notFound();return rs.getObject(1,UUID.class);},
          actor.organizationId(),actor.userId());
        Integer count=jdbc.queryForObject("""
          SELECT COUNT(*) FROM booking_hold WHERE organization_id=? AND customer_id=?
             AND status='ACTIVE' AND expires_at>transaction_timestamp()
          """,Integer.class,actor.organizationId(),actor.userId());
        if(count!=null && count>=maxHolds) throw DomainProblem.invalid("ACTIVE_HOLD_LIMIT_REACHED","Too many active holds.");
        ServiceSnapshot service=catalog.service(actor.organizationId(),req.serviceId(),req.locationId());
        AvailabilityEngine.Allocation allocation=availability.allocate(actor.organizationId(),service,req.startAt(),req.preferredStaffId())
            .orElseThrow(DomainProblem::conflict);
        UUID id=UUID.randomUUID();Instant expires=store.databaseNow().plusSeconds(ttl);
        jdbc.update("""
          INSERT INTO booking_hold(id,organization_id,customer_id,service_id,location_id,start_at,end_at,zone_id,status,service_name_snapshot,duration_minutes_snapshot,buffer_before_minutes_snapshot,buffer_after_minutes_snapshot,cancel_deadline_minutes_snapshot,reschedule_deadline_minutes_snapshot,expires_at)
          VALUES(?,?,?,?,?,?,?,?, 'ACTIVE',?,?,?,?,?,?,?)
          """,id,actor.organizationId(),actor.userId(),req.serviceId(),req.locationId(),
          SqlTime.utc(req.startAt()),SqlTime.utc(allocation.appointmentEnd()),service.zone().getId(),service.name(),service.durationMinutes(),service.bufferBeforeMinutes(),service.bufferAfterMinutes(),service.cancelDeadlineMinutes(),service.rescheduleDeadlineMinutes(),SqlTime.utc(expires));
        reservation.reserveForHold(actor.organizationId(),id,allocation.resources(),allocation.occupiedStart(),allocation.occupiedEnd());
        audit.record(actor.organizationId(),actor.userId(),"BOOKING_HOLD_CREATED",id);
        return id;
    });
    requireOwner(actor,store.holdCustomer(actor.organizationId(),result.id()));
    return store.hold(actor.organizationId(),result.id(),false);
 }
 @Transactional(readOnly=true)
 public BookingHoldResponse getHold(Actor actor,UUID id){
    requireOwner(actor,store.holdCustomer(actor.organizationId(),id));
    return store.hold(actor.organizationId(),id,false);
 }
 @Transactional
 public AppointmentResponse confirmHold(Actor actor,UUID holdId,String key){
    var r=idempotency.execute(actor.organizationId(),actor.userId(),"CONFIRM_HOLD",key,actor.organizationId()+"|"+holdId,()->{
        BookingHoldResponse hold=store.hold(actor.organizationId(),holdId,true);
        requireOwner(actor,store.holdCustomer(actor.organizationId(),holdId));
        if(!hold.status().equals("ACTIVE")) throw DomainProblem.invalid("INVALID_BOOKING_HOLD_TRANSITION","Booking hold is not active.");
        if(!hold.expiresAt().isAfter(store.databaseNow()))
            throw new DomainProblem(HttpStatus.CONFLICT,"BOOKING_HOLD_EXPIRED","Booking hold expired.");
        UUID appointment=UUID.randomUUID();
        BookingStore.HoldServiceSnapshot service=store.holdSnapshot(actor.organizationId(),holdId);
        UUID owner=store.holdCustomer(actor.organizationId(),holdId);
        jdbc.update("""
          INSERT INTO appointment(id,organization_id,customer_id,service_id,location_id,start_at,end_at,
              zone_id,status,service_name_snapshot,duration_minutes_snapshot,buffer_before_minutes_snapshot,buffer_after_minutes_snapshot,cancel_deadline_minutes_snapshot,reschedule_deadline_minutes_snapshot)
          VALUES(?,?,?,?,?,?,?,?, 'CONFIRMED',?,?,?,?,?,?)
          """,appointment,actor.organizationId(),owner,hold.serviceId(),hold.locationId(),
             SqlTime.utc(hold.startAt()),SqlTime.utc(hold.endAt()),hold.timeZone(),service.name(),service.durationMinutes(),service.bufferBefore(),service.bufferAfter(),service.cancelDeadline(),service.rescheduleDeadline());
        reservation.convertHoldToAppointment(actor.organizationId(),holdId,appointment);
        jdbc.update("UPDATE booking_hold SET status='CONFIRMED',appointment_id=? WHERE organization_id=? AND id=?",
           appointment,actor.organizationId(),holdId);
        audit.record(actor.organizationId(),actor.userId(),"APPOINTMENT_BOOKED",appointment);
        outbox.append(actor.organizationId(),"AppointmentBooked",appointment);
        return appointment;
    });
    AppointmentResponse a=store.appointment(actor.organizationId(),r.id(),false);
    requireOwner(actor,a.customerUserProfileId());
    return a;
 }
 @Transactional
 public BookingHoldResponse cancelHold(Actor actor,UUID holdId,String key){
    var r=idempotency.execute(actor.organizationId(),actor.userId(),"CANCEL_HOLD",key,actor.organizationId()+"|"+holdId,()->{
        BookingHoldResponse hold=store.hold(actor.organizationId(),holdId,true);
        requireOwner(actor,store.holdCustomer(actor.organizationId(),holdId));
        if(!hold.status().equals("ACTIVE"))throw DomainProblem.invalid("INVALID_BOOKING_HOLD_TRANSITION","Booking hold is not active.");
        jdbc.update("UPDATE booking_hold SET status='CANCELLED' WHERE organization_id=? AND id=?",actor.organizationId(),holdId);
        reservation.releaseHold(actor.organizationId(),holdId);
        audit.record(actor.organizationId(),actor.userId(),"BOOKING_HOLD_CANCELLED",holdId);
        return holdId;
    });
    requireOwner(actor,store.holdCustomer(actor.organizationId(),r.id()));
    return store.hold(actor.organizationId(),r.id(),false);
 }
 @Transactional(readOnly=true)
 public AppointmentResponse getAppointment(Actor actor,UUID appointmentId){
    AppointmentResponse a=store.appointment(actor.organizationId(),appointmentId,false);
    requireOwner(actor,a.customerUserProfileId());return a;
 }
 @Transactional
 public AppointmentResponse directBook(Actor actor,String key,CreateDirectBookingRequest req){
    if(!actor.canManage()) throw DomainProblem.forbidden();
    var result=idempotency.execute(actor.organizationId(),actor.userId(),"DIRECT_BOOK",key,actor.organizationId()+"|"+req,()->{
        // Ensure delegated customer actually belongs to the organization.
        Integer n=jdbc.queryForObject("""
          SELECT COUNT(*) FROM organization_membership WHERE organization_id=? AND user_profile_id=? AND state='ACTIVE'
          """,Integer.class,actor.organizationId(),req.customerUserProfileId());
        if(n==null || n==0)throw DomainProblem.notFound();
        ServiceSnapshot s=catalog.service(actor.organizationId(),req.serviceId(),req.locationId());
        var allocation=availability.allocate(actor.organizationId(),s,req.startAt(),req.preferredStaffId()).orElseThrow(DomainProblem::conflict);
        UUID id=UUID.randomUUID();
        jdbc.update("""
          INSERT INTO appointment(id,organization_id,customer_id,service_id,location_id,start_at,end_at,zone_id,
          status,service_name_snapshot,duration_minutes_snapshot,buffer_before_minutes_snapshot,buffer_after_minutes_snapshot,cancel_deadline_minutes_snapshot,reschedule_deadline_minutes_snapshot)
          VALUES(?,?,?,?,?,?,?,?, 'CONFIRMED',?,?,?,?,?,?)
          """,id,actor.organizationId(),req.customerUserProfileId(),req.serviceId(),req.locationId(),
          SqlTime.utc(req.startAt()),SqlTime.utc(allocation.appointmentEnd()),s.zone().getId(),s.name(),s.durationMinutes(),s.bufferBeforeMinutes(),s.bufferAfterMinutes(),s.cancelDeadlineMinutes(),s.rescheduleDeadlineMinutes());
        reservation.reserveForAppointment(actor.organizationId(),id,allocation.resources(),allocation.occupiedStart(),allocation.occupiedEnd());
        audit.record(actor.organizationId(),actor.userId(),"APPOINTMENT_BOOKED",id);
        outbox.append(actor.organizationId(),"AppointmentBooked",id);
        return id;
    });
    return store.appointment(actor.organizationId(),result.id(),false);
 }
 @Transactional
 public AppointmentResponse cancelAppointment(Actor actor,UUID id,String ifMatch,String key,String reason){
    var result=idempotency.execute(actor.organizationId(),actor.userId(),"CANCEL_APPOINTMENT",key,actor.organizationId()+"|"+id+"|"+ifMatch+"|"+reason,()->{
        AppointmentResponse a=store.appointment(actor.organizationId(),id,true);
        requireOwner(actor,a.customerUserProfileId());checkVersion(ifMatch,a.version());
        if(!a.status().equals("CONFIRMED") && !a.status().equals("CHECKED_IN"))
            throw DomainProblem.invalid("INVALID_APPOINTMENT_TRANSITION","Appointment cannot be cancelled in its current state.");
        enforceDeadline(actor,id,"cancel_deadline_minutes_snapshot",a.startAt(),"CANCELLATION_DEADLINE_PASSED");
        jdbc.update("""
           UPDATE appointment SET status='CANCELLED',version=version+1,updated_at=NOW()
           WHERE organization_id=? AND id=?
           """,actor.organizationId(),id);
        reservation.releaseAppointment(actor.organizationId(),id);
        audit.record(actor.organizationId(),actor.userId(),"APPOINTMENT_CANCELLED",id);
        outbox.append(actor.organizationId(),"AppointmentCancelled",id);
        return id;
    });
    return getAppointment(actor,result.id());
 }
 private void enforceDeadline(Actor actor,UUID appointment,String column,Instant appointmentStart,String errorCode){
    if(actor.canManage()) return; // Explicit privileged override; audited by the command.
    if(!column.equals("cancel_deadline_minutes_snapshot") && !column.equals("reschedule_deadline_minutes_snapshot"))
        throw new IllegalArgumentException("Invalid policy column");
    Integer minutes=jdbc.queryForObject("SELECT "+column+" FROM appointment WHERE organization_id=? AND id=?",
          Integer.class,actor.organizationId(),appointment);
    if(minutes==null || !store.databaseNow().isBefore(appointmentStart.minusSeconds(minutes*60L)))
        throw DomainProblem.invalid(errorCode,"The booking policy deadline has passed.");
 }
 private void checkVersion(String header,long version){
    if(header==null || header.isBlank())
        throw new DomainProblem(HttpStatus.PRECONDITION_REQUIRED,"PRECONDITION_REQUIRED","If-Match is required.");
    if(!header.equals("\"v"+version+"\""))
        throw new DomainProblem(HttpStatus.PRECONDITION_FAILED,"PRECONDITION_FAILED","Resource version no longer matches.");
 }
 @Transactional
 public AppointmentResponse reschedule(Actor actor,UUID id,String ifMatch,String key,RescheduleAppointmentRequest request){
    var result=idempotency.execute(actor.organizationId(),actor.userId(),"RESCHEDULE_APPOINTMENT",key,actor.organizationId()+"|"+id+"|"+ifMatch+"|"+request,()->{
        AppointmentResponse a=store.appointment(actor.organizationId(),id,true);
        requireOwner(actor,a.customerUserProfileId());checkVersion(ifMatch,a.version());
        if(!a.status().equals("CONFIRMED"))throw DomainProblem.invalid("INVALID_APPOINTMENT_TRANSITION","Only confirmed appointments may be rescheduled.");
        enforceDeadline(actor,id,"reschedule_deadline_minutes_snapshot",a.startAt(),"RESCHEDULE_DEADLINE_PASSED");
        ServiceSnapshot current=catalog.service(actor.organizationId(),a.serviceId(),request.locationId());
        BookingStore.AppointmentTiming timing=store.appointmentTiming(actor.organizationId(),id);
        ServiceSnapshot s=new ServiceSnapshot(current.serviceId(),current.locationId(),current.name(),
            timing.durationMinutes(),timing.before(),timing.after(),current.noticeMinutes(),current.horizonDays(),
            current.cancelDeadlineMinutes(),current.rescheduleDeadlineMinutes(),current.zone());
        var allocation=availability.allocateExcludingAppointment(actor.organizationId(),s,request.startAt(),request.preferredStaffId(),id).orElseThrow(DomainProblem::conflict);
        reservation.releaseAppointment(actor.organizationId(),id);
        reservation.reserveForAppointment(actor.organizationId(),id,allocation.resources(),allocation.occupiedStart(),allocation.occupiedEnd());
        jdbc.update("""
          UPDATE appointment SET location_id=?,start_at=?,end_at=?,zone_id=?,version=version+1,updated_at=NOW()
          WHERE organization_id=? AND id=?
          """,request.locationId(),SqlTime.utc(request.startAt()),SqlTime.utc(allocation.appointmentEnd()),s.zone().getId(),actor.organizationId(),id);
        audit.record(actor.organizationId(),actor.userId(),"APPOINTMENT_RESCHEDULED",id);
        outbox.append(actor.organizationId(),"AppointmentRescheduled",id);
        return id;
    });
    return getAppointment(actor,result.id());
 }
}
