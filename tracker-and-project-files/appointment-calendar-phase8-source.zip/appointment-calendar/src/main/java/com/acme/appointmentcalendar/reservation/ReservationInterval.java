package com.acme.appointmentcalendar.reservation;
import java.time.Instant;
import java.util.Objects;
public record ReservationInterval(Instant start,Instant end) {
    public ReservationInterval {
        Objects.requireNonNull(start);Objects.requireNonNull(end);
        if(!end.isAfter(start)) throw new IllegalArgumentException("End must follow start");
    }
    public boolean overlaps(ReservationInterval other) {
        return start.isBefore(other.end()) && end.isAfter(other.start());
    }
}
