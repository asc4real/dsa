package com.acme.appointmentcalendar.shared;
