@org.springframework.modulith.NamedInterface("error")
package com.acme.appointmentcalendar.shared.error;
