package com.acme.appointmentcalendar.reservation;
import com.acme.appointmentcalendar.shared.SqlTime;
import com.acme.appointmentcalendar.shared.error.DomainProblem;
import java.time.Instant;
import java.util.UUID;
import java.util.List;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
@Service
public class ReservationStore {
    private final JdbcTemplate jdbc;
    public ReservationStore(JdbcTemplate jdbc) {this.jdbc=jdbc;}
    public boolean isFree(UUID org,UUID resource,Instant start,Instant end) {
        return isFreeExcluding(org,resource,start,end,null);
    }
    public boolean isFreeExcluding(UUID org,UUID resource,Instant start,Instant end,UUID excludedAppointment) {
        Integer n=jdbc.queryForObject("""
            SELECT COUNT(*) FROM resource_reservation
            WHERE organization_id=? AND resource_id=? AND state='ACTIVE'
              AND occupied_start < ? AND occupied_end > ?
              AND (? IS NULL OR appointment_id IS DISTINCT FROM ?)
            """,Integer.class,org,resource,SqlTime.utc(end),SqlTime.utc(start),excludedAppointment,excludedAppointment);
        return n!=null && n==0;
    }
    public void reserveForHold(UUID org, UUID holdId,List<UUID> resources,Instant start,Instant end) {
        for(UUID resource:resources.stream().sorted().toList()) {
            try {
                jdbc.update("""
                  INSERT INTO resource_reservation
                    (id,organization_id,resource_id,booking_hold_id,occupied_start,occupied_end)
                  VALUES (?,?,?,?,?,?)
                """,UUID.randomUUID(),org,resource,holdId,SqlTime.utc(start),SqlTime.utc(end));
            } catch(DataIntegrityViolationException e) {
                if(isOverlap(e)) throw DomainProblem.conflict();
                throw e;
            }
        }
    }
    public void reserveForAppointment(UUID org,UUID appointmentId,List<UUID> resources,Instant start,Instant end) {
        for(UUID resource:resources.stream().sorted().toList()) {
            try {
                jdbc.update("""
                   INSERT INTO resource_reservation
                    (id,organization_id,resource_id,appointment_id,occupied_start,occupied_end)
                   VALUES (?,?,?,?,?,?)
                   """,UUID.randomUUID(),org,resource,appointmentId,SqlTime.utc(start),SqlTime.utc(end));
            } catch(DataIntegrityViolationException e) {
                if(isOverlap(e)) throw DomainProblem.conflict();
                throw e;
            }
        }
    }
    private boolean isOverlap(Throwable e) {
        for(Throwable t=e;t!=null;t=t.getCause()) {
            if(t instanceof java.sql.SQLException sql && "23P01".equals(sql.getSQLState())) return true;
        }
        return false;
    }
    public void convertHoldToAppointment(UUID org,UUID hold,UUID appointment) {
        int changed=jdbc.update("""
             UPDATE resource_reservation SET booking_hold_id=NULL,appointment_id=?
             WHERE organization_id=? AND booking_hold_id=? AND state='ACTIVE'
             """,appointment,org,hold);
        if(changed<1) throw DomainProblem.conflict();
    }
    public void releaseHold(UUID org,UUID hold) {
        jdbc.update("UPDATE resource_reservation SET state='RELEASED' WHERE organization_id=? AND booking_hold_id=? AND state='ACTIVE'",org,hold);
    }
    public void releaseAppointment(UUID org,UUID appointment) {
        jdbc.update("UPDATE resource_reservation SET state='RELEASED' WHERE organization_id=? AND appointment_id=? AND state='ACTIVE'",org,appointment);
    }
}
