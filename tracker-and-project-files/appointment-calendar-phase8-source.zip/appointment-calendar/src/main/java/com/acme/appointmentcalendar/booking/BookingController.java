package com.acme.appointmentcalendar.booking;
import com.acme.appointmentcalendar.security.Actor;
import com.acme.appointmentcalendar.security.TenantAccessPolicy;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/v1/organizations/{orgId}")
public class BookingController {
 private final BookingApplicationService service;
 private final TenantAccessPolicy access;
 public BookingController(BookingApplicationService service,TenantAccessPolicy access){this.service=service;this.access=access;}
 @PostMapping("/booking-holds")
 public ResponseEntity<BookingHoldResponse> createHold(@PathVariable UUID orgId, Authentication auth,
       @RequestHeader("Idempotency-Key") String key,@Valid @RequestBody CreateBookingHoldRequest request){
    Actor actor=access.require(auth,orgId);
    BookingHoldResponse result=service.createHold(actor,key,request);
    return ResponseEntity.created(URI.create("/api/v1/organizations/"+orgId+"/booking-holds/"+result.id())).body(result);
 }
 @GetMapping("/booking-holds/{holdId}")
 public BookingHoldResponse getHold(@PathVariable UUID orgId,@PathVariable UUID holdId,Authentication auth){
    return service.getHold(access.require(auth,orgId),holdId);
 }
 @PostMapping("/booking-holds/{holdId}/confirm")
 public ResponseEntity<AppointmentResponse> confirm(@PathVariable UUID orgId,@PathVariable UUID holdId,
      Authentication auth,@RequestHeader("Idempotency-Key") String key){
    var appointment=service.confirmHold(access.require(auth,orgId),holdId,key);
    return ResponseEntity.ok().eTag("\"v"+appointment.version()+"\"").body(appointment);
 }
 @PostMapping("/booking-holds/{holdId}/cancel")
 public BookingHoldResponse cancelHold(@PathVariable UUID orgId,@PathVariable UUID holdId,
      Authentication auth,@RequestHeader("Idempotency-Key") String key){
    return service.cancelHold(access.require(auth,orgId),holdId,key);
 }
 @GetMapping("/appointments/{appointmentId}")
 public ResponseEntity<AppointmentResponse> getAppointment(@PathVariable UUID orgId,
      @PathVariable UUID appointmentId,Authentication auth){
    var a=service.getAppointment(access.require(auth,orgId),appointmentId);
    return ResponseEntity.ok().eTag("\"v"+a.version()+"\"").body(a);
 }
 @PostMapping("/appointments")
 public ResponseEntity<AppointmentResponse> direct(@PathVariable UUID orgId,Authentication auth,
       @RequestHeader("Idempotency-Key") String key,@Valid @RequestBody CreateDirectBookingRequest request){
    var a=service.directBook(access.require(auth,orgId),key,request);
    return ResponseEntity.created(URI.create("/api/v1/organizations/"+orgId+"/appointments/"+a.id()))
           .eTag("\"v"+a.version()+"\"").body(a);
 }
 public record CancellationRequest(@jakarta.validation.constraints.Size(max=512) String reason) {}
 @PostMapping("/appointments/{appointmentId}/cancel")
 public ResponseEntity<AppointmentResponse> cancel(@PathVariable UUID orgId,@PathVariable UUID appointmentId,
       Authentication auth,@RequestHeader("Idempotency-Key") String key,
       @RequestHeader(value="If-Match",required=false) String etag,@Valid @RequestBody CancellationRequest request){
    var a=service.cancelAppointment(access.require(auth,orgId),appointmentId,etag,key,request.reason());
    return ResponseEntity.ok().eTag("\"v"+a.version()+"\"").body(a);
 }
 @PostMapping("/appointments/{appointmentId}/reschedule")
 public ResponseEntity<AppointmentResponse> reschedule(@PathVariable UUID orgId,@PathVariable UUID appointmentId,
      Authentication auth,@RequestHeader("Idempotency-Key") String key,
      @RequestHeader(value="If-Match",required=false) String etag,
      @Valid @RequestBody RescheduleAppointmentRequest request){
    var a=service.reschedule(access.require(auth,orgId),appointmentId,etag,key,request);
    return ResponseEntity.ok().eTag("\"v"+a.version()+"\"").body(a);
 }
}
