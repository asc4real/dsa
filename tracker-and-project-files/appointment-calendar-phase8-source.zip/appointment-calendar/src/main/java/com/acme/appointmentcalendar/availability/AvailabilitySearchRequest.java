package com.acme.appointmentcalendar.availability;
import jakarta.validation.constraints.NotNull;
import java.util.UUID;
import java.time.LocalDate;
public record AvailabilitySearchRequest(@NotNull UUID serviceId,@NotNull UUID locationId,
        @NotNull LocalDate dateFrom,@NotNull LocalDate dateToExclusive,
        UUID preferredStaffId,String displayTimeZone) {}
