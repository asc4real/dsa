package com.acme.appointmentcalendar.shared.error;
import org.springframework.http.HttpStatus;
public final class DomainProblem extends RuntimeException {
    private final HttpStatus status;
    private final String code;
    public DomainProblem(HttpStatus status, String code, String safeDetail) {
        super(safeDetail);
        this.status=status; this.code=code;
    }
    public HttpStatus status() {return status;}
    public String code() {return code;}
    public static DomainProblem notFound() {return new DomainProblem(HttpStatus.NOT_FOUND,"RESOURCE_NOT_FOUND","Resource not found.");}
    public static DomainProblem forbidden() {return new DomainProblem(HttpStatus.FORBIDDEN,"ACCESS_DENIED","Access denied.");}
    public static DomainProblem conflict() {return new DomainProblem(HttpStatus.CONFLICT,"APPOINTMENT_SLOT_CONFLICT","The requested time is no longer available.");}
    public static DomainProblem invalid(String code, String detail) {return new DomainProblem(HttpStatus.UNPROCESSABLE_ENTITY,code,detail);}
}
