package com.acme.appointmentcalendar.catalog;
import com.acme.appointmentcalendar.shared.error.DomainProblem;
import java.util.UUID;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import java.time.ZoneId;
@Service
public class CatalogReader {
    private final JdbcTemplate jdbc;
    public CatalogReader(JdbcTemplate jdbc) {this.jdbc=jdbc;}
    public ServiceSnapshot service(UUID org, UUID service, UUID location) {
        ServiceSnapshot result=jdbc.query("""
             SELECT s.name,s.duration_minutes,s.buffer_before_minutes,s.buffer_after_minutes,
                    s.notice_minutes,s.horizon_days,s.cancel_deadline_minutes,s.reschedule_deadline_minutes,l.zone_id
             FROM bookable_service s JOIN service_location sl
                 ON sl.organization_id=s.organization_id AND sl.service_id=s.id
             JOIN location l ON l.organization_id=sl.organization_id AND l.id=sl.location_id
             WHERE s.organization_id=? AND s.id=? AND l.id=?
                 AND s.active=true AND l.active=true
             """,rs -> rs.next() ? new ServiceSnapshot(service,location,rs.getString(1),
             rs.getInt(2),rs.getInt(3),rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getInt(7),rs.getInt(8),
             ZoneId.of(rs.getString(9))) : null, org,service,location);
        if(result==null) throw DomainProblem.notFound();
        return result;
    }
    public record Candidate(UUID resourceId,UUID staffId,String resourceType) {}
    public record Requirement(String key, List<Candidate> eligible) {}
    public List<Requirement> requirements(UUID org,UUID service,UUID location,UUID preferredStaffId) {
        List<String> groups=jdbc.query("""
           SELECT requirement_key FROM service_resource_requirement
           WHERE organization_id=? AND service_id=? ORDER BY requirement_key
           """,(rs,row)->rs.getString(1),org,service);
        if(groups.isEmpty() || groups.size()>6) throw DomainProblem.invalid("INVALID_SERVICE_CONFIGURATION","Unsupported resource requirements.");
        return groups.stream().map(group -> {
            List<Candidate> candidates=jdbc.query("""
               SELECT r.id,r.staff_member_id,r.type FROM service_resource_requirement req
               JOIN service_resource_eligibility e ON e.organization_id=req.organization_id AND e.requirement_id=req.id
               JOIN calendar_resource r ON r.organization_id=e.organization_id AND r.id=e.resource_id
               WHERE req.organization_id=? AND req.service_id=? AND req.requirement_key=?
                 AND r.location_id=? AND r.active=true AND r.type=req.resource_type
                 AND (? IS NULL OR r.type <> 'STAFF_MEMBER' OR r.staff_member_id=?)
               ORDER BY r.id LIMIT 21
               """,(rs,row)->new Candidate(rs.getObject(1,UUID.class),rs.getObject(2,UUID.class),rs.getString(3)),
               org,service,group,location,preferredStaffId,preferredStaffId);
            if(candidates.isEmpty() || candidates.size()>20) throw DomainProblem.invalid("RESOURCE_NOT_ELIGIBLE","No supported eligible resource allocation.");
            return new Requirement(group,candidates);
        }).toList();
    }
}
