package com.acme.appointmentcalendar.outbox;
import java.util.UUID;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
@Service
public class OutboxWriter {
 private final JdbcTemplate jdbc;
 public OutboxWriter(JdbcTemplate jdbc){this.jdbc=jdbc;}
 public void append(UUID organization,String kind,UUID target){
     jdbc.update("""
        INSERT INTO outbox_event(id,organization_id,event_type,aggregate_id,payload)
        VALUES (?,?,?,?, CAST(? AS jsonb))
        """,UUID.randomUUID(),organization,kind,target,"{\"targetId\":\""+target+"\"}");
 }
}
