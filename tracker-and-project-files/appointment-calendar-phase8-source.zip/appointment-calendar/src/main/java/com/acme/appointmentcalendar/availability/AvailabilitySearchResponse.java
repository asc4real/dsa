package com.acme.appointmentcalendar.availability;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
public record AvailabilitySearchResponse(UUID serviceId,UUID locationId,String timeZone,
        Instant generatedAt,List<AvailableSlot> availableSlots,boolean truncated,boolean advisory) {}
