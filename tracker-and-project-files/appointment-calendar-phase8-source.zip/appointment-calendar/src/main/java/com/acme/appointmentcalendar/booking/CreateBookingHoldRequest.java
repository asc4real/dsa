package com.acme.appointmentcalendar.booking;
import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.UUID;
public record CreateBookingHoldRequest(@NotNull UUID serviceId,@NotNull UUID locationId,
        @NotNull Instant startAt,UUID preferredStaffId) {}
