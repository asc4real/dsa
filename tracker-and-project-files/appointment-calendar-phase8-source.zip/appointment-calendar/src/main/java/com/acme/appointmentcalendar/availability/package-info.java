package com.acme.appointmentcalendar.availability;
