package com.acme.appointmentcalendar.availability;
import java.time.Instant;
import java.util.UUID;
public record AvailableSlot(Instant startAt,Instant endAt,String localStart,String localEnd,UUID staffId) {}
