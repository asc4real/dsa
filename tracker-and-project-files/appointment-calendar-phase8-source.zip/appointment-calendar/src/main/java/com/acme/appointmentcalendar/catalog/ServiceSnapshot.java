package com.acme.appointmentcalendar.catalog;
import java.util.UUID;
import java.time.ZoneId;
public record ServiceSnapshot(UUID serviceId, UUID locationId, String name,
        int durationMinutes, int bufferBeforeMinutes,int bufferAfterMinutes,
        int noticeMinutes,int horizonDays,int cancelDeadlineMinutes,int rescheduleDeadlineMinutes,ZoneId zone) {}
