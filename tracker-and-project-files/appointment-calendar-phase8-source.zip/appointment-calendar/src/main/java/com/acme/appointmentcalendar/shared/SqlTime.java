package com.acme.appointmentcalendar.shared;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.sql.ResultSet;
import java.sql.SQLException;
public final class SqlTime {
    private SqlTime() {}
    public static OffsetDateTime utc(Instant time) { return time.atOffset(ZoneOffset.UTC); }
    public static Instant read(ResultSet rs, String column) throws SQLException {
        return rs.getObject(column, OffsetDateTime.class).toInstant();
    }
}
