package com.acme.appointmentcalendar.operations;
import com.acme.appointmentcalendar.reservation.ReservationStore;
import java.util.UUID;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
@Component
public class HoldExpiryWorker {
 private final JdbcTemplate jdbc;
 private final ReservationStore reservation;
 public HoldExpiryWorker(JdbcTemplate jdbc,ReservationStore reservation){this.jdbc=jdbc;this.reservation=reservation;}
 @Scheduled(fixedDelayString="PT15S")
 @Transactional
 public void expireBatch(){
     List<HoldRef> ids=jdbc.query("""
        SELECT organization_id,id FROM booking_hold
        WHERE status='ACTIVE' AND expires_at<=transaction_timestamp()
        ORDER BY expires_at,id FOR UPDATE SKIP LOCKED LIMIT 100
        """,(rs,row)->new HoldRef(rs.getObject(1,UUID.class),rs.getObject(2,UUID.class)));
     for(var ref:ids){
        jdbc.update("UPDATE booking_hold SET status='EXPIRED' WHERE organization_id=? AND id=? AND status='ACTIVE'",ref.org,ref.id);
        reservation.releaseHold(ref.org,ref.id);
     }
 }
 private record HoldRef(UUID org,UUID id) {}
}
