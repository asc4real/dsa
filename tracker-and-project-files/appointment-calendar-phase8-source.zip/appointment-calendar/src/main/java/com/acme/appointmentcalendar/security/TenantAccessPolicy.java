package com.acme.appointmentcalendar.security;
import com.acme.appointmentcalendar.shared.error.DomainProblem;
import java.util.UUID;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Service;
@Service
public class TenantAccessPolicy {
    private final JdbcTemplate jdbc;
    public TenantAccessPolicy(JdbcTemplate jdbc) { this.jdbc=jdbc; }
    public Actor require(Authentication authentication, UUID orgId) {
        if (!(authentication instanceof JwtAuthenticationToken token)) throw DomainProblem.forbidden();
        String issuer=token.getToken().getIssuer().toString();
        String subject=token.getToken().getSubject();
        Actor found=jdbc.query("""
             SELECT u.id, m.role FROM user_profile u
             JOIN organization_membership m ON m.user_profile_id=u.id
             JOIN organization o ON o.id=m.organization_id
             WHERE u.issuer=? AND u.subject=? AND m.organization_id=?
             AND m.state='ACTIVE' AND o.status='ACTIVE'
             """, rs -> rs.next() ? new Actor(rs.getObject(1,UUID.class),orgId,rs.getString(2)) : null,
             issuer,subject,orgId);
        if(found==null) throw DomainProblem.notFound();
        return found;
    }
}
