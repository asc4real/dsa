package com.acme.appointmentcalendar.booking;
import com.acme.appointmentcalendar.shared.SqlTime;
import com.acme.appointmentcalendar.shared.error.DomainProblem;
import java.util.UUID;
import java.time.Instant;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
@Service
public class BookingStore {
 private final JdbcTemplate jdbc;
 public BookingStore(JdbcTemplate jdbc){this.jdbc=jdbc;}
 public BookingHoldResponse hold(UUID org, UUID holdId,boolean lock) {
     String query="""
         SELECT id,organization_id,service_id,location_id,start_at,end_at,zone_id,status,expires_at,appointment_id
         FROM booking_hold WHERE organization_id=? AND id=?
         """+(lock?" FOR UPDATE":"");
     BookingHoldResponse result=jdbc.query(query,rs -> rs.next()? mapHold(rs):null,org,holdId);
     if(result==null) throw DomainProblem.notFound();
     return result;
 }
 private BookingHoldResponse mapHold(ResultSet rs) throws SQLException {
    return new BookingHoldResponse(rs.getObject("id",UUID.class),rs.getObject("organization_id",UUID.class),
       rs.getObject("service_id",UUID.class),rs.getObject("location_id",UUID.class),
       SqlTime.read(rs,"start_at"),SqlTime.read(rs,"end_at"),rs.getString("zone_id"),
       rs.getString("status"),SqlTime.read(rs,"expires_at"),rs.getObject("appointment_id",UUID.class));
 }
 public record HoldServiceSnapshot(String name,int durationMinutes,int bufferBefore,int bufferAfter,int cancelDeadline,int rescheduleDeadline) {}
 public HoldServiceSnapshot holdSnapshot(UUID org,UUID holdId) {
     HoldServiceSnapshot snapshot=jdbc.query("""
         SELECT service_name_snapshot,duration_minutes_snapshot,buffer_before_minutes_snapshot,buffer_after_minutes_snapshot,cancel_deadline_minutes_snapshot,reschedule_deadline_minutes_snapshot FROM booking_hold
         WHERE organization_id=? AND id=?
         """, rs -> rs.next()?new HoldServiceSnapshot(rs.getString(1),rs.getInt(2),rs.getInt(3),rs.getInt(4),rs.getInt(5),rs.getInt(6)):null,org,holdId);
     if(snapshot==null) throw DomainProblem.notFound();
     return snapshot;
 }

 public UUID holdCustomer(UUID org,UUID hold){
    UUID user=jdbc.query("SELECT customer_id FROM booking_hold WHERE organization_id=? AND id=?",rs->rs.next()?rs.getObject(1,UUID.class):null,org,hold);
    if(user==null) throw DomainProblem.notFound();return user;
 }
 public AppointmentResponse appointment(UUID org,UUID appointmentId,boolean lock){
    String query="""
        SELECT id,organization_id,service_id,location_id,customer_id,start_at,end_at,zone_id,status,
               service_name_snapshot,duration_minutes_snapshot,created_at,updated_at,version
        FROM appointment WHERE organization_id=? AND id=?
        """+(lock?" FOR UPDATE":"");
    AppointmentResponse result=jdbc.query(query,rs->rs.next()?mapAppointment(rs):null,org,appointmentId);
    if(result==null) throw DomainProblem.notFound();return result;
 }
 private AppointmentResponse mapAppointment(ResultSet rs) throws SQLException {
    return new AppointmentResponse(rs.getObject("id",UUID.class),rs.getObject("organization_id",UUID.class),
       rs.getObject("service_id",UUID.class),rs.getObject("location_id",UUID.class),rs.getObject("customer_id",UUID.class),
       SqlTime.read(rs,"start_at"),SqlTime.read(rs,"end_at"),rs.getString("zone_id"),rs.getString("status"),
       rs.getString("service_name_snapshot"),rs.getInt("duration_minutes_snapshot"),
       SqlTime.read(rs,"created_at"),SqlTime.read(rs,"updated_at"),rs.getLong("version"));
 }
 public record AppointmentTiming(int durationMinutes,int before,int after) {}
 public AppointmentTiming appointmentTiming(UUID org,UUID appointmentId) {
     AppointmentTiming t=jdbc.query("""
         SELECT duration_minutes_snapshot,buffer_before_minutes_snapshot,buffer_after_minutes_snapshot
         FROM appointment WHERE organization_id=? AND id=?
         """,rs->rs.next()?new AppointmentTiming(rs.getInt(1),rs.getInt(2),rs.getInt(3)):null,org,appointmentId);
     if(t==null) throw DomainProblem.notFound();
     return t;
 }
 public Instant databaseNow() {
    return jdbc.queryForObject("SELECT transaction_timestamp()",java.time.OffsetDateTime.class).toInstant();
 }
}
