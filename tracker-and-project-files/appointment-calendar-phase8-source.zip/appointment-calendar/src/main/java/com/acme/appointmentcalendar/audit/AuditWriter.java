package com.acme.appointmentcalendar.audit;
import java.util.UUID;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
@Service
public class AuditWriter {
 private final JdbcTemplate jdbc;
 public AuditWriter(JdbcTemplate jdbc){this.jdbc=jdbc;}
 public void record(UUID org,UUID actor,String event,UUID target){
    jdbc.update("INSERT INTO audit_event(id,organization_id,actor_id,event_type,target_id) VALUES (?,?,?,?,?)",
        UUID.randomUUID(),org,actor,event,target);
 }
}
