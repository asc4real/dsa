package com.acme.appointmentcalendar.booking;
import java.util.UUID;
import java.time.Instant;
public record AppointmentResponse(UUID id,UUID organizationId,UUID serviceId,UUID locationId,
    UUID customerUserProfileId,Instant startAt,Instant endAt,String timeZone,String status,
    String serviceNameSnapshot,int durationMinutesSnapshot,Instant createdAt,Instant updatedAt,long version) {}
