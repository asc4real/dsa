package com.acme.appointmentcalendar.idempotency;
import com.acme.appointmentcalendar.shared.error.DomainProblem;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.UUID;
import java.util.function.Supplier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.http.HttpStatus;
@Service
public class IdempotencyCoordinator {
    private final JdbcTemplate jdbc;
    public IdempotencyCoordinator(JdbcTemplate jdbc){this.jdbc=jdbc;}
    public record Result(UUID id, boolean replay) {}
    public Result execute(UUID organizationId,UUID actorId,String operation,String key,String normalizedPayload,Supplier<UUID> work){
        if(key==null || !key.matches("[A-Za-z0-9_.:-]{8,128}"))
            throw new DomainProblem(HttpStatus.BAD_REQUEST,"IDEMPOTENCY_KEY_REQUIRED","A valid Idempotency-Key is required.");
        String hash=sha256(normalizedPayload);
        int inserted=jdbc.update("""
            INSERT INTO idempotency_record(organization_id,actor_id,operation,idem_key,payload_sha256)
            VALUES (?,?,?,?,?) ON CONFLICT DO NOTHING
            """,organizationId,actorId,operation,key,hash);
        if(inserted==0){
            return jdbc.query("""
               SELECT payload_sha256,resource_id FROM idempotency_record
               WHERE organization_id=? AND actor_id=? AND operation=? AND idem_key=?
               """, rs -> {
                if(!rs.next()) throw DomainProblem.conflict();
                if(!hash.equals(rs.getString(1)))
                    throw new DomainProblem(HttpStatus.CONFLICT,"IDEMPOTENCY_KEY_REUSED","Idempotency key used for a different request.");
                UUID id=rs.getObject(2,UUID.class);
                if(id==null) throw new DomainProblem(HttpStatus.CONFLICT,"IDEMPOTENCY_REQUEST_IN_PROGRESS","Request still processing.");
                return new Result(id,true);
               },organizationId,actorId,operation,key);
        }
        UUID id=work.get();
        jdbc.update("""
             UPDATE idempotency_record SET resource_id=?,http_status=201
             WHERE organization_id=? AND actor_id=? AND operation=? AND idem_key=?
             """,id,organizationId,actorId,operation,key);
        return new Result(id,false);
    }
    private static String sha256(String value){
        try {
            byte[] hash=MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}
    }
}
