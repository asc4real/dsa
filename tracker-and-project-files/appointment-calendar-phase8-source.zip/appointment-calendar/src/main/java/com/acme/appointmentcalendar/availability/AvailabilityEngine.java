package com.acme.appointmentcalendar.availability;
import com.acme.appointmentcalendar.catalog.CatalogReader;
import com.acme.appointmentcalendar.catalog.ServiceSnapshot;
import com.acme.appointmentcalendar.reservation.ReservationStore;
import com.acme.appointmentcalendar.shared.SqlTime;
import com.acme.appointmentcalendar.shared.error.DomainProblem;
import java.time.*;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
@Service
public class AvailabilityEngine {
    private final JdbcTemplate jdbc;
    private final CatalogReader catalog;
    private final ReservationStore reservations;
    private final Clock clock;
    public AvailabilityEngine(JdbcTemplate jdbc,CatalogReader catalog,ReservationStore reservations,Clock clock){
        this.jdbc=jdbc;this.catalog=catalog;this.reservations=reservations;this.clock=clock;
    }
    public record Allocation(List<UUID> resources,Instant appointmentEnd,Instant occupiedStart,Instant occupiedEnd) {}
    public Optional<Allocation> allocate(UUID org,ServiceSnapshot service,Instant start,UUID preferredStaff){
        return allocateExcludingAppointment(org,service,start,preferredStaff,null);
    }
    public Optional<Allocation> allocateExcludingAppointment(UUID org,ServiceSnapshot service,Instant start,
            UUID preferredStaff,UUID excludedAppointment){
        Instant end=start.plusSeconds(60L*service.durationMinutes());
        Instant occupiedStart=start.minusSeconds(60L*service.bufferBeforeMinutes());
        Instant occupiedEnd=end.plusSeconds(60L*service.bufferAfterMinutes());
        Instant now=clock.instant();
        if(start.isBefore(now.plusSeconds(60L*service.noticeMinutes())) ||
           start.isAfter(now.plus(Duration.ofDays(service.horizonDays())))) return Optional.empty();
        List<CatalogReader.Requirement> groups=catalog.requirements(org,service.serviceId(),service.locationId(),preferredStaff);
        ArrayList<UUID> result=new ArrayList<>();
        boolean success=allocateGroup(org,groups,0,occupiedStart,occupiedEnd,service.zone(),new HashSet<>(),result,excludedAppointment);
        return success ? Optional.of(new Allocation(List.copyOf(result),end,occupiedStart,occupiedEnd)) : Optional.empty();
    }
    private boolean allocateGroup(UUID org,List<CatalogReader.Requirement> groups,int index,
         Instant start,Instant end,ZoneId zone,Set<UUID> chosen,List<UUID> result,UUID excludedAppointment){
        if(index==groups.size()) return true;
        for(var resource:groups.get(index).eligible()){
            if(chosen.contains(resource.resourceId())) continue;
            if(!available(org,resource.resourceId(),start,end,zone,excludedAppointment)) continue;
            chosen.add(resource.resourceId());result.add(resource.resourceId());
            if(allocateGroup(org,groups,index+1,start,end,zone,chosen,result,excludedAppointment)) return true;
            result.remove(result.size()-1);chosen.remove(resource.resourceId());
        }
        return false;
    }
    private boolean available(UUID org,UUID resource,Instant start,Instant end,ZoneId zone,UUID excludedAppointment) {
        ZonedDateTime localStart=start.atZone(zone),localEnd=end.atZone(zone);
        // Phase 8 slice supports same-local-day occupancy rules only. Never silently accept cross-day cases.
        if(!localStart.toLocalDate().equals(localEnd.minusNanos(1).toLocalDate())) return false;
        int weekday=localStart.getDayOfWeek().getValue();
        Integer matching=jdbc.queryForObject("""
            SELECT COUNT(*) FROM availability_rule
            WHERE organization_id=? AND resource_id=? AND iso_weekday=?
              AND local_start<=? AND local_end>=?
            """,Integer.class,org,resource,weekday,localStart.toLocalTime(),localEnd.toLocalTime());
        if(matching==null || matching==0) return false;
        Integer off=jdbc.queryForObject("""
            SELECT COUNT(*) FROM resource_unavailability
            WHERE organization_id=? AND resource_id=? AND start_at<? AND end_at>?
            """,Integer.class,org,resource,SqlTime.utc(end),SqlTime.utc(start));
        return off!=null && off==0 && reservations.isFreeExcluding(org,resource,start,end,excludedAppointment);
    }
    public AvailabilitySearchResponse search(UUID org, AvailabilitySearchRequest req, int maxDays,int maxSlots) {
        if(!req.dateToExclusive().isAfter(req.dateFrom()) ||
            java.time.temporal.ChronoUnit.DAYS.between(req.dateFrom(),req.dateToExclusive())>maxDays)
            throw new DomainProblem(org.springframework.http.HttpStatus.BAD_REQUEST,"SEARCH_RANGE_TOO_LARGE","Invalid or excessive date interval.");
        ServiceSnapshot s=catalog.service(org,req.serviceId(),req.locationId());
        ZoneId display;
        try { display=req.displayTimeZone()==null?s.zone():ZoneId.of(req.displayTimeZone()); }
        catch(DateTimeException ex) {throw new DomainProblem(org.springframework.http.HttpStatus.BAD_REQUEST,"INVALID_TIME_ZONE","Unsupported timezone.");}
        ArrayList<AvailableSlot> slots=new ArrayList<>();boolean truncated=false;
        outer: for(LocalDate date=req.dateFrom();date.isBefore(req.dateToExclusive());date=date.plusDays(1)){
            for(int min=0;min<24*60;min+=15){
                LocalDateTime local=date.atStartOfDay().plusMinutes(min);
                // Explicitly skip nonexistent DST times and preserve both offsets on overlaps.
                for(ZoneOffset offset:s.zone().getRules().getValidOffsets(local)){
                    Instant instant=local.atOffset(offset).toInstant();
                    Optional<Allocation> result=allocate(org,s,instant,req.preferredStaffId());
                    if(result.isEmpty()) continue;
                    if(slots.size()>=maxSlots){truncated=true;break outer;}
                    Instant end=result.get().appointmentEnd();
                    UUID staffId=null;
                    if(req.preferredStaffId()!=null) staffId=req.preferredStaffId();
                    slots.add(new AvailableSlot(instant,end,
                      instant.atZone(display).toOffsetDateTime().toString(),
                      end.atZone(display).toOffsetDateTime().toString(),staffId));
                }
            }
        }
        return new AvailabilitySearchResponse(req.serviceId(),req.locationId(),display.getId(),clock.instant(),List.copyOf(slots),truncated,true);
    }
}
