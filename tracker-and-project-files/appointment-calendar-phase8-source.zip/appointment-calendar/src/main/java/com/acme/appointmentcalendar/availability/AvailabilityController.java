package com.acme.appointmentcalendar.availability;
import com.acme.appointmentcalendar.security.TenantAccessPolicy;
import jakarta.validation.Valid;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/v1/organizations/{orgId}/availability")
public class AvailabilityController {
    private final AvailabilityEngine engine;
    private final TenantAccessPolicy access;
    private final int maxDays,maxSlots;
    public AvailabilityController(AvailabilityEngine engine,TenantAccessPolicy access,
           @Value("${app.booking.search-max-days}") int maxDays,
           @Value("${app.booking.max-returned-slots}") int maxSlots){
        this.engine=engine;this.access=access;this.maxDays=maxDays;this.maxSlots=maxSlots;
    }
    @PostMapping("/search")
    public AvailabilitySearchResponse search(@PathVariable UUID orgId,Authentication auth,
             @Valid @RequestBody AvailabilitySearchRequest req){
        access.require(auth,orgId);
        return engine.search(orgId,req,maxDays,maxSlots);
    }
}
