package com.acme.appointmentcalendar.persistence;
import java.sql.*;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.Test;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.postgresql.PostgreSQLContainer;
import static org.assertj.core.api.Assertions.assertThat;
@Testcontainers
class NoDoubleBooking100ThreadsIT {
 @Container
 static final PostgreSQLContainer postgres=new PostgreSQLContainer("postgres:18-alpine")
       .withDatabaseName("appointments_test").withUsername("test").withPassword("test");
 @Test void oneOfOneHundredOverlappingReservationsWins() throws Exception {
   Flyway.configure().dataSource(postgres.getJdbcUrl(),postgres.getUsername(),postgres.getPassword())
          .locations("classpath:db/migration").load().migrate();
   UUID org=UUID.randomUUID(),user=UUID.randomUUID(),location=UUID.randomUUID(),
        service=UUID.randomUUID(),resource=UUID.randomUUID();
   var holds=new ArrayList<UUID>();
   try(Connection con=open()) {
      exec(con,"INSERT INTO organization(id,name,zone_id) VALUES (?,?,?)",org,"Test","UTC");
      exec(con,"INSERT INTO user_profile(id,issuer,subject,display_name) VALUES (?,?,?,?)",user,"test-issuer","test-subject","Test User");
      exec(con,"INSERT INTO organization_membership(organization_id,user_profile_id,role) VALUES (?,?,?)",org,user,"CUSTOMER");
      exec(con,"INSERT INTO location(id,organization_id,name,zone_id) VALUES (?,?,?,?)",location,org,"Main","UTC");
      exec(con,"INSERT INTO calendar_resource(id,organization_id,location_id,type,name) VALUES (?,?,?,?,?)",resource,org,location,"ROOM","Room");
      exec(con,"INSERT INTO bookable_service(id,organization_id,name,duration_minutes) VALUES (?,?,?,?)",service,org,"Consultation",30);
      for(int i=0;i<100;i++){
          UUID hold=UUID.randomUUID();holds.add(hold);
          exec(con,"""
            INSERT INTO booking_hold(id,organization_id,customer_id,service_id,location_id,start_at,end_at,zone_id,
             status,service_name_snapshot,duration_minutes_snapshot,buffer_before_minutes_snapshot,buffer_after_minutes_snapshot,cancel_deadline_minutes_snapshot,reschedule_deadline_minutes_snapshot,expires_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,hold,org,user,service,location,OffsetDateTime.parse("2026-10-20T10:00:00Z"),
            OffsetDateTime.parse("2026-10-20T10:30:00Z"),"UTC","ACTIVE","Consultation",30,0,0,1440,1440,
            OffsetDateTime.parse("2026-10-20T10:05:00Z"));
      }
   }
   ExecutorService executor=Executors.newFixedThreadPool(16);
   CountDownLatch start=new CountDownLatch(1);
   List<Future<Boolean>> futures=new ArrayList<>();
   for(UUID hold:holds){
       futures.add(executor.submit(()->{
           start.await();
           try(Connection c=open()) {
               exec(c,"""
                 INSERT INTO resource_reservation(id,organization_id,resource_id,booking_hold_id,occupied_start,occupied_end)
                 VALUES(?,?,?,?,?,?)
                 """,UUID.randomUUID(),org,resource,hold,
                 OffsetDateTime.parse("2026-10-20T10:00:00Z"),OffsetDateTime.parse("2026-10-20T10:30:00Z"));
               return true;
           } catch(SQLException e) {
               if("23P01".equals(e.getSQLState())) return false;
               throw e;
           }
       }));
   }
   start.countDown();
   int successes=0;
   try {
       for(Future<Boolean> f:futures) if(f.get(45,TimeUnit.SECONDS)) successes++;
   } finally { executor.shutdownNow(); }
   assertThat(successes).isEqualTo(1);
   try(Connection con=open();Statement s=con.createStatement();ResultSet rs=s.executeQuery("SELECT COUNT(*) FROM resource_reservation WHERE state='ACTIVE'")) {
       rs.next();assertThat(rs.getInt(1)).isEqualTo(1);
   }
 }
 private Connection open() throws SQLException {return DriverManager.getConnection(postgres.getJdbcUrl(),postgres.getUsername(),postgres.getPassword());}
 private static void exec(Connection c,String sql,Object... args)throws SQLException {
     try(PreparedStatement p=c.prepareStatement(sql)) {
         for(int i=0;i<args.length;i++)p.setObject(i+1,args[i]);
         p.executeUpdate();
     }
 }
}
