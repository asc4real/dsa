package com.acme.appointmentcalendar.availability;
import java.time.*;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
class DaylightSavingRulesTest {
 @Test void springGapDoesNotExist(){
    var rules=ZoneId.of("America/New_York").getRules();
    assertThat(rules.getValidOffsets(LocalDateTime.parse("2026-03-08T02:30:00"))).isEmpty();
 }
 @Test void fallOverlapProducesTwoInstants(){
    var rules=ZoneId.of("America/New_York").getRules();
    assertThat(rules.getValidOffsets(LocalDateTime.parse("2026-11-01T01:30:00"))).hasSize(2);
 }
}
