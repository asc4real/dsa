package com.acme.appointmentcalendar.architecture;

import com.acme.appointmentcalendar.AppointmentCalendarApplication;
import org.junit.jupiter.api.Test;
import org.springframework.modulith.core.ApplicationModules;

class ModuleBoundariesTest {
    @Test
    void modularArchitectureHasNoCyclesOrIllegalInternalImports() {
        ApplicationModules.of(AppointmentCalendarApplication.class).verify();
    }
}
