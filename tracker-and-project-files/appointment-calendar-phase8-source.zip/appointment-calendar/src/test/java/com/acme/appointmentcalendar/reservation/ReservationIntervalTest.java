package com.acme.appointmentcalendar.reservation;
import org.junit.jupiter.api.Test;
import java.time.Instant;
import static org.assertj.core.api.Assertions.*;
class ReservationIntervalTest {
 @Test void touchingHalfOpenIntervalsDoNotOverlap(){
   Instant a=Instant.parse("2026-10-20T10:00:00Z");
   Instant b=a.plusSeconds(1800);
   assertThat(new ReservationInterval(a,b).overlaps(new ReservationInterval(b,b.plusSeconds(1800)))).isFalse();
 }
 @Test void oneMillisecondOverlapIsDetected(){
   Instant a=Instant.parse("2026-10-20T10:00:00Z");
   Instant b=a.plusSeconds(1800);
   assertThat(new ReservationInterval(a,b).overlaps(new ReservationInterval(b.minusMillis(1),b.plusSeconds(1800)))).isTrue();
 }
 @Test void rejectEmptyAndBackwards(){
   Instant a=Instant.parse("2026-10-20T10:00:00Z");
   assertThatThrownBy(()->new ReservationInterval(a,a)).isInstanceOf(IllegalArgumentException.class);
   assertThatThrownBy(()->new ReservationInterval(a,a.minusSeconds(1))).isInstanceOf(IllegalArgumentException.class);
 }
}
