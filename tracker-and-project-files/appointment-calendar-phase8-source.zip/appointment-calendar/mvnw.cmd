@echo off
setlocal
set "VERSION=3.9.11"
set "CACHE=%USERPROFILE%\.m2\wrapper\dists\appointment-calendar-maven-%VERSION%"
set "MVN=%CACHE%\apache-maven-%VERSION%\bin\mvn.cmd"
if exist "%MVN%" goto run
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $path='%CACHE%'; New-Item -ItemType Directory -Force -Path $path | Out-Null; $zip=Join-Path $path 'apache-maven-%VERSION%-bin.zip'; if (-not (Test-Path $zip)) { Invoke-WebRequest -Uri 'https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/%VERSION%/apache-maven-%VERSION%-bin.zip' -OutFile $zip }; if ((Get-FileHash -Path $zip -Algorithm SHA512).Hash.ToLowerInvariant() -ne '03e2d65d4483a3396980629f260e25cac0d8b6f7f2791e4dc20bc83f9514db8d0f05b0479e699a5f34679250c49c8e52e961262ded468a20de0be254d8207076') { throw 'Maven distribution checksum mismatch' }; Expand-Archive -Path $zip -DestinationPath $path -Force"
if errorlevel 1 exit /b 1
:run
call "%MVN%" %*
